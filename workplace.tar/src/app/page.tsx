import { Hero } from "@/components/hero";
import { ProductGrid } from "@/components/product-grid";
import { CategoryShowcase } from "@/components/category-showcase";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <CategoryShowcase />
        <ProductGrid />
      </main>
      <Footer />
    </div>
  );
}