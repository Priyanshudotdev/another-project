import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ShopHub - Your One-Stop Online Shopping Destination",
  description: "Discover amazing products at great prices. Shop the latest trends in electronics, fashion, home goods, and more with fast shipping and excellent customer service.",
  keywords: ["ShopHub", "e-commerce", "online shopping", "electronics", "fashion", "home goods", "deals"],
  authors: [{ name: "ShopHub Team" }],
  openGraph: {
    title: "ShopHub - Online Shopping Made Easy",
    description: "Shop thousands of products at competitive prices with fast shipping and excellent customer service.",
    url: "https://shophub.com",
    siteName: "ShopHub",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ShopHub - Online Shopping Made Easy",
    description: "Shop thousands of products at competitive prices with fast shipping and excellent customer service.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
