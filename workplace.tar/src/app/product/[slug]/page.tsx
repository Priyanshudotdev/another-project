"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Star, 
  Heart, 
  ShoppingCart, 
  Share2,
  Truck,
  Shield,
  RotateCcw,
  ChevronLeft,
  Plus,
  Minus
} from "lucide-react";
import { useCartStore } from "@/store/cart-store";

// Mock product data - in a real app, this would be fetched based on the slug
const mockProduct = {
  id: "1",
  name: "Wireless Bluetooth Headphones",
  price: 79.99,
  comparePrice: 99.99,
  image: "/placeholder-product.jpg",
  images: ["/placeholder-product.jpg", "/placeholder-product-2.jpg", "/placeholder-product-3.jpg"],
  slug: "wireless-bluetooth-headphones",
  rating: 4.5,
  reviewCount: 128,
  badge: "Best Seller",
  category: "Electronics",
  inStock: true,
  quantity: 50,
  description: "Experience premium sound quality with these wireless Bluetooth headphones. Featuring advanced noise cancellation, 30-hour battery life, and comfortable over-ear design.",
  features: [
    "Active Noise Cancellation",
    "30-hour battery life",
    "Bluetooth 5.0",
    "Quick charge: 5 min = 2 hours playback",
    "Comfortable over-ear design",
    "Foldable and portable",
    "Built-in microphone",
    "Premium audio drivers"
  ],
  specifications: {
    "Driver Size": "40mm",
    "Frequency Response": "20Hz - 20kHz",
    "Impedance": "32 Ohms",
    "Battery Life": "30 hours",
    "Charging Time": "2 hours",
    "Wireless Range": "10 meters",
    "Weight": "250g",
    "Connectivity": "Bluetooth 5.0, 3.5mm jack"
  },
  reviews: [
    {
      id: "1",
      user: "John D.",
      rating: 5,
      title: "Amazing sound quality!",
      comment: "These headphones exceeded my expectations. The sound is crystal clear and the noise cancellation is top-notch.",
      date: "2024-01-15",
      verified: true
    },
    {
      id: "2",
      user: "Sarah M.",
      rating: 4,
      title: "Great value for money",
      comment: "Really happy with this purchase. The battery life is incredible and they're very comfortable for long listening sessions.",
      date: "2024-01-10",
      verified: true
    },
    {
      id: "3",
      user: "Mike R.",
      rating: 5,
      title: "Perfect for daily commute",
      comment: "The noise cancellation makes my train ride so much more peaceful. Highly recommend!",
      date: "2024-01-05",
      verified: true
    }
  ]
};

const relatedProducts = [
  {
    id: "2",
    name: "Smart Fitness Watch",
    price: 199.99,
    image: "/placeholder-product.jpg",
    slug: "smart-fitness-watch",
    rating: 4.8,
  },
  {
    id: "4",
    name: "Wireless Charging Pad",
    price: 29.99,
    image: "/placeholder-product.jpg",
    slug: "wireless-charging-pad",
    rating: 4.6,
  },
  {
    id: "5",
    name: "Bluetooth Speaker",
    price: 59.99,
    image: "/placeholder-product.jpg",
    slug: "bluetooth-speaker",
    rating: 4.4,
  },
];

function ProductImageGallery() {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  return (
    <div className="space-y-4">
      {/* Main image */}
      <div className="aspect-square bg-muted rounded-lg flex items-center justify-center">
        <div className="text-center space-y-2">
          <div className="text-6xl">📦</div>
          <p className="text-sm text-muted-foreground">Product Image {selectedImageIndex + 1}</p>
        </div>
      </div>
      
      {/* Thumbnail gallery */}
      <div className="grid grid-cols-4 gap-2">
        {mockProduct.images.map((_, index) => (
          <button
            key={index}
            onClick={() => setSelectedImageIndex(index)}
            className={`aspect-square bg-muted rounded border-2 transition-colors ${
              selectedImageIndex === index 
                ? "border-primary" 
                : "border-transparent hover:border-primary/50"
            }`}
          >
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-2xl">📷</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function AddToCartSection() {
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore((state) => state.addItem);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addItem({
        id: mockProduct.id,
        name: mockProduct.name,
        price: mockProduct.price,
        image: mockProduct.image,
        slug: mockProduct.slug,
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-4">
        <span className="text-sm font-medium">Quantity:</span>
        <div className="flex items-center border rounded-lg">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            disabled={quantity <= 1}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <span className="px-4 py-2 text-center min-w-[3rem]">{quantity}</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setQuantity(quantity + 1)}
            disabled={quantity >= mockProduct.quantity}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <span className="text-sm text-muted-foreground">
          {mockProduct.quantity} available
        </span>
      </div>

      <div className="space-y-2">
        <Button 
          className="w-full" 
          size="lg"
          onClick={handleAddToCart}
          disabled={!mockProduct.inStock}
        >
          <ShoppingCart className="h-5 w-5 mr-2" />
          Add to Cart
        </Button>
        
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" size="lg">
            <Heart className="h-5 w-5 mr-2" />
            Wishlist
          </Button>
          <Button variant="outline" size="lg">
            <Share2 className="h-5 w-5 mr-2" />
            Share
          </Button>
        </div>
      </div>
    </div>
  );
}

function ReviewCard({ review }: { review: typeof mockProduct.reviews[0] }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < review.rating
                        ? "text-yellow-500 fill-current"
                        : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              {review.verified && (
                <Badge variant="secondary" className="text-xs">
                  Verified Purchase
                </Badge>
              )}
            </div>
            <span className="text-sm text-muted-foreground">{review.date}</span>
          </div>
          
          <div>
            <h4 className="font-semibold">{review.title}</h4>
            <p className="text-sm text-muted-foreground">by {review.user}</p>
          </div>
          
          <p className="text-sm">{review.comment}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ProductPage() {
  const params = useParams();
  const slug = params.slug as string;

  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <div className="border-b bg-muted/50">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center space-x-2 text-sm">
            <Link href="/" className="hover:text-primary transition-colors">
              Home
            </Link>
            <span>/</span>
            <Link href="/products" className="hover:text-primary transition-colors">
              Products
            </Link>
            <span>/</span>
            <Link 
              href={`/category/${mockProduct.category.toLowerCase().replace(' & ', '-')}`}
              className="hover:text-primary transition-colors"
            >
              {mockProduct.category}
            </Link>
            <span>/</span>
            <span className="text-muted-foreground">{mockProduct.name}</span>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Back button */}
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/products">
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Products
          </Link>
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Product images */}
          <div>
            <ProductImageGallery />
          </div>

          {/* Product details */}
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <h1 className="text-3xl font-bold">{mockProduct.name}</h1>
                {mockProduct.badge && (
                  <Badge>{mockProduct.badge}</Badge>
                )}
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(mockProduct.rating)
                            ? "text-yellow-500 fill-current"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium">{mockProduct.rating}</span>
                  <span className="text-sm text-muted-foreground">
                    ({mockProduct.reviewCount} reviews)
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center space-x-3">
                <span className="text-3xl font-bold">
                  ${mockProduct.price.toFixed(2)}
                </span>
                {mockProduct.comparePrice && (
                  <>
                    <span className="text-lg text-muted-foreground line-through">
                      ${mockProduct.comparePrice.toFixed(2)}
                    </span>
                    <Badge variant="destructive">
                      Save ${(mockProduct.comparePrice - mockProduct.price).toFixed(2)}
                    </Badge>
                  </>
                )}
              </div>
            </div>

            <p className="text-muted-foreground">{mockProduct.description}</p>

            <AddToCartSection />

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t">
              <div className="flex items-center space-x-2">
                <Truck className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-medium">Free Shipping</p>
                  <p className="text-xs text-muted-foreground">On orders over $50</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-medium">Secure Payment</p>
                  <p className="text-xs text-muted-foreground">100% secure</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <RotateCcw className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-medium">Easy Returns</p>
                  <p className="text-xs text-muted-foreground">30-day policy</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product details tabs */}
        <div className="mb-12">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="features">Features</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {mockProduct.description}
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="features" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {mockProduct.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <div className="h-2 w-2 bg-primary rounded-full"></div>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="specifications" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(mockProduct.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between py-2 border-b">
                        <span className="font-medium">{key}</span>
                        <span className="text-muted-foreground">{value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-6">
                {/* Review summary */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-6">
                      <div className="text-center">
                        <div className="text-4xl font-bold">{mockProduct.rating}</div>
                        <div className="flex items-center justify-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < Math.floor(mockProduct.rating)
                                  ? "text-yellow-500 fill-current"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          {mockProduct.reviewCount} reviews
                        </p>
                      </div>
                      
                      <div className="flex-1 space-y-2">
                        {[5, 4, 3, 2, 1].map((rating) => (
                          <div key={rating} className="flex items-center space-x-2">
                            <span className="text-sm w-3">{rating}</span>
                            <Star className="h-3 w-3 text-yellow-500 fill-current" />
                            <div className="flex-1 bg-muted rounded-full h-2">
                              <div 
                                className="bg-yellow-500 h-2 rounded-full"
                                style={{
                                  width: `${(mockProduct.reviews.filter(r => r.rating === rating).length / mockProduct.reviews.length) * 100}%`
                                }}
                              ></div>
                            </div>
                            <span className="text-sm text-muted-foreground w-8">
                              {mockProduct.reviews.filter(r => r.rating === rating).length}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Individual reviews */}
                <div className="space-y-4">
                  {mockProduct.reviews.map((review) => (
                    <ReviewCard key={review.id} review={review} />
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related products */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedProducts.map((product) => (
              <Card key={product.id} className="group overflow-hidden hover:shadow-lg transition-all duration-200">
                <CardContent className="p-4">
                  <div className="aspect-square bg-muted rounded-lg mb-4 flex items-center justify-center">
                    <div className="text-center space-y-2">
                      <div className="text-4xl">📦</div>
                      <p className="text-sm text-muted-foreground">Product Image</p>
                    </div>
                  </div>
                  
                  <h3 className="font-semibold text-sm mb-2 line-clamp-2">
                    <Link 
                      href={`/product/${product.slug}`}
                      className="hover:text-primary transition-colors"
                    >
                      {product.name}
                    </Link>
                  </h3>
                  
                  <div className="flex items-center space-x-1 mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-3 w-3 ${
                            i < Math.floor(product.rating)
                              ? "text-yellow-500 fill-current"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {product.rating}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold">
                      ${product.price.toFixed(2)}
                    </span>
                    <Button size="sm" variant="outline">
                      View
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}